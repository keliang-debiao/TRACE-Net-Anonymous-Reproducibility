# Reference execution traces

These traces are generated deterministically from manuscript-locked counts and tables by `scripts/build_reference_artifacts.py`. Their purpose is to verify parsing, stage order, formulas, output schemas, and reporting arithmetic before a costly run.

They are not accelerator records, training telemetry, or proof that a hardware run occurred. Real execution records are written to `runs/` with current UTC timestamps, resolved configurations, software inventory, checkpoint hashes, and data fingerprints. Reference files are immutable during ordinary execution.
