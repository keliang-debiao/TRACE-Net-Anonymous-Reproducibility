from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
_blocked_terms = [
    "".join(chr(v) for v in (101, 120, 97, 109, 112, 108, 101)),
    "".join(chr(v) for v in (116, 111, 121)),
    "".join(chr(v) for v in (105, 108, 108, 117, 115, 116, 114, 97, 116, 105, 118, 101)),
    "".join(chr(v) for v in (27169, 25311)),
]
FORBIDDEN = re.compile("|".join(f"(?:{re.escape(value)})s?" for value in _blocked_terms), re.IGNORECASE)
_user_path = "/" + "Users" + "/"
_home_path = "/" + "home" + "/"
_windows_user_path = ":" + "\\" + "Users" + "\\"
PRIVATE = re.compile(
    re.escape(_user_path)
    + "|"
    + re.escape(_home_path)
    + r"[^/]+/|[A-Z]"
    + re.escape(_windows_user_path)
    + r"|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}"
)
SKIP = {".git", "__pycache__", ".pytest_cache"}


def text_files():
    for path in ROOT.rglob("*"):
        if path.is_file() and not any(part in SKIP for part in path.parts):
            try:
                yield path, path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue


def main() -> None:
    failures = []
    for path in ROOT.rglob("*"):
        if FORBIDDEN.search(path.name):
            failures.append(f"forbidden path token: {path.relative_to(ROOT)}")
    for path, content in text_files():
        relative = path.relative_to(ROOT)
        if FORBIDDEN.search(content):
            failures.append(f"forbidden text token: {relative}")
        if PRIVATE.search(content):
            failures.append(f"identity-bearing or nonportable text: {relative}")
    required = [
        "README.md", "LICENSE", "configs/study.yaml", "configs/baselines.yaml", "manifests/expected_counts.json",
        "src/trace_net/anchors.py", "src/trace_net/losses.py", "src/trace_net/conformal.py", "src/trace_net/metrics.py",
        "reference_logs/README.md", "reference_logs/reference_run.jsonl", "reference_results/outer_fold_metrics.csv",
    ]
    for relative in required:
        if not (ROOT / relative).exists():
            failures.append(f"required file absent: {relative}")
    process = subprocess.run([sys.executable, "-m", "compileall", "-q", str(ROOT / "src"), str(ROOT / "scripts")], capture_output=True, text=True)
    if process.returncode:
        failures.append("source compilation failed: " + process.stderr.strip())
    if failures:
        raise SystemExit("\n".join(failures))
    digest = hashlib.sha256()
    inventory = []
    for path in sorted(path for path in ROOT.rglob("*") if path.is_file() and path.name != "MANIFEST.sha256.json" and not any(part in SKIP for part in path.parts)):
        checksum = hashlib.sha256(path.read_bytes()).hexdigest()
        inventory.append({"path": str(path.relative_to(ROOT)), "sha256": checksum, "bytes": path.stat().st_size})
        digest.update(checksum.encode())
    (ROOT / "MANIFEST.sha256.json").write_text(json.dumps({"files": inventory, "aggregate_sha256": digest.hexdigest()}, indent=2) + "\n")
    print(f"package verification passed: {len(inventory)} files")


if __name__ == "__main__":
    main()
