from __future__ import annotations

import argparse
from pathlib import Path


ABLATIONS = ["no_residual_interaction", "no_beta_binomial_dispersion", "no_temporal_objective", "no_groupdro", "no_weighted_conformal", "no_rank_loss", "simplified_encoder"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    Path("runs/ablation_plan.txt").parent.mkdir(parents=True, exist_ok=True)
    Path("runs/ablation_plan.txt").write_text("\n".join(ABLATIONS) + "\n")
    print("ablation plan written; execute each condition under the same locked folds and seeds")


if __name__ == "__main__":
    main()
