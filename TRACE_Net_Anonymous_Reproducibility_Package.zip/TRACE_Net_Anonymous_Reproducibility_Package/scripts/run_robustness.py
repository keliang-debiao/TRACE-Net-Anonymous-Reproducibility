from __future__ import annotations

import argparse
from pathlib import Path


CONDITIONS = ["clean", "temperature_scaled", "context_missing_10", "context_missing_25", "token_noise_5", "late_holdout", "prior_shift_worst", "train_75", "train_50", "lowest_exposure_quartile"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    Path("runs/robustness_plan.txt").parent.mkdir(parents=True, exist_ok=True)
    Path("runs/robustness_plan.txt").write_text("\n".join(CONDITIONS) + "\n")
    print("robustness plan written; apply conditions only to their declared legal partition")


if __name__ == "__main__":
    main()
