from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from trace_net.metrics import fold_summary


FOLDS = {
    "lift_proxy_mae_pp": [0.817, 0.842, 0.789, 0.861, 0.828],
    "winner_accuracy": [0.684, 0.671, 0.697, 0.663, 0.679],
    "kendall_tau": [0.344, 0.327, 0.361, 0.319, 0.338],
    "bb_enll_nats_per_impression": [0.061, 0.063, 0.060, 0.064, 0.062],
    "coverage_90": [0.903, 0.894, 0.911, 0.887, 0.906],
    "interval_width_pp": [3.801, 3.944, 3.736, 4.102, 3.865],
}


def read_csv(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    events = []
    events.append({"sequence": 1, "stage": "contract", "status": "passed", "detail": "locked protocols loaded", "trace_type": "deterministic_reference"})
    expected = json.loads((ROOT / "manifests/expected_counts.json").read_text())
    totals = expected["upworthy_primary"]
    for field in ("arms", "clicks", "impressions"):
        actual = sum(int(row[field]) for row in expected["outer_folds"])
        if actual != totals[field]:
            raise AssertionError(f"outer-fold {field} total mismatch")
    events.append({"sequence": 2, "stage": "cohort_arithmetic", "status": "passed", "detail": totals, "trace_type": "deterministic_reference"})
    anchor = expected["anchor_counts"]
    eligible = np.asarray([row["eligible"] for row in anchor], dtype=float)
    if not math.isclose(float(eligible.mean()), 227.4, abs_tol=1e-12) or not math.isclose(float(eligible.std(ddof=1)), 8.561541917, rel_tol=1e-8):
        raise AssertionError("eligible-anchor summary mismatch")
    events.append({"sequence": 3, "stage": "anchor_arithmetic", "status": "passed", "detail": {"mean": eligible.mean(), "sd": eligible.std(ddof=1)}, "trace_type": "deterministic_reference"})
    summaries = {}
    for metric, values in FOLDS.items():
        summaries[metric] = fold_summary(values)
    locked = {
        "lift_proxy_mae_pp": (0.8274, 0.027043, 0.793822, 0.860978),
        "winner_accuracy": (0.6788, 0.012931, 0.662745, 0.694855),
        "kendall_tau": (0.3378, 0.016177, 0.317713, 0.357887),
        "bb_enll_nats_per_impression": (0.0620, 0.001581, 0.060037, 0.063963),
        "coverage_90": (0.9002, 0.009628, 0.888245, 0.912155),
        "interval_width_pp": (3.8896, 0.141528, 3.713869, 4.065331),
    }
    for metric, result in summaries.items():
        for key, target in zip(("mean", "sd", "ci_low", "ci_high"), locked[metric]):
            if not math.isclose(result[key], target, abs_tol=6e-5):
                raise AssertionError(f"{metric}.{key} mismatch: {result[key]} versus {target}")
    events.append({"sequence": 4, "stage": "fold_statistics", "status": "passed", "detail": summaries, "trace_type": "deterministic_reference"})
    if int(expected["late_holdout"]["anchor"]["supported"]) + int(expected["late_holdout"]["anchor"]["unsupported"]) != int(expected["late_holdout"]["holdout"]["strata"]):
        raise AssertionError("late-holdout support partition mismatch")
    events.append({"sequence": 5, "stage": "late_holdout", "status": "passed", "detail": expected["late_holdout"], "trace_type": "deterministic_reference"})
    external = read_csv(ROOT / "reference_results/external_validation.csv")
    if not any(row["protocol"] == "External-0" and row["pr_auc_mean"] == "0.151" for row in external):
        raise AssertionError("strict external result is absent")
    events.append({"sequence": 6, "stage": "external_schema", "status": "passed", "detail": {"rows": len(external)}, "trace_type": "deterministic_reference"})
    events.append({"sequence": 7, "stage": "complete", "status": "passed", "detail": "reference contract verified", "trace_type": "deterministic_reference"})
    log_path = ROOT / "reference_logs/reference_run.jsonl"
    log_path.write_text("".join(json.dumps(event, sort_keys=True) + "\n" for event in events), encoding="utf-8")
    summary_path = ROOT / "reference_results/fold_summary_recalculated.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["metric", "mean", "sd", "ci_low", "ci_high"])
        writer.writeheader()
        for metric, result in summaries.items():
            writer.writerow({"metric": metric, **{key: f"{value:.6f}" for key, value in result.items()}})
    if args.check:
        print("reference artifacts verified")


if __name__ == "__main__":
    main()
