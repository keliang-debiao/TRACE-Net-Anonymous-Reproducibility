from __future__ import annotations

import argparse
import shutil
import subprocess
import zipfile
from pathlib import Path

import requests


MIND_URL = "https://mind201910small.blob.core.windows.net/release/MINDsmall_train.zip"


def fetch_upworthy(root: Path) -> None:
    if shutil.which("kaggle") is None:
        raise RuntimeError("the Kaggle client is not installed")
    root.mkdir(parents=True, exist_ok=True)
    subprocess.run(["kaggle", "datasets", "download", "-d", "akshaysyal/heading-performance-analysis", "-p", str(root), "--unzip"], check=True)


def fetch_mind(root: Path) -> None:
    root.mkdir(parents=True, exist_ok=True)
    archive = root / "MINDsmall_train.zip"
    with requests.get(MIND_URL, stream=True, timeout=120) as response:
        response.raise_for_status()
        with archive.open("wb") as handle:
            for block in response.iter_content(1024 * 1024):
                handle.write(block)
    with zipfile.ZipFile(archive) as bundle:
        bundle.extractall(root)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["upworthy", "mind", "all"], required=True)
    args = parser.parse_args()
    if args.dataset in {"upworthy", "all"}:
        fetch_upworthy(Path("data/raw/upworthy"))
    if args.dataset in {"mind", "all"}:
        fetch_mind(Path("data/raw/mind"))


if __name__ == "__main__":
    main()
