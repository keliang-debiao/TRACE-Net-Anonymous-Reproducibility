from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import yaml


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--fold", type=int, choices=range(1, 6))
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    configuration = yaml.safe_load(args.config.read_text())
    folds = [args.fold] if args.fold else list(range(1, 6))
    seeds = [args.seed] if args.seed else configuration["study"]["seeds"]
    for fold in folds:
        for seed in seeds:
            command = [sys.executable, "scripts/train_one.py", "--config", str(args.config), "--fold", str(fold), "--seed", str(seed)]
            subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
