from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from trace_net.data import prepare_upworthy_frame
from trace_net.splitting import leakage_components


ALIASES = {
    "arm_id": ["arm_id", "id", "headline_id"],
    "test_id": ["test_id", "clickability_test_id"],
    "eyecatcher_id": ["eyecatcher_id", "image_id"],
    "headline": ["headline", "headline_text"],
    "supporting_text": ["supporting_text", "excerpt"],
    "clicks": ["clicks"],
    "impressions": ["impressions"],
    "started_at": ["started_at", "created_at", "test_start_time"],
}


def locate_column(columns, choices):
    for value in choices:
        if value in columns:
            return value
    raise ValueError(f"none of the accepted source columns is present: {choices}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    files = sorted(args.input.rglob("*.csv")) if args.input.is_dir() else [args.input]
    if not files:
        raise FileNotFoundError("no CSV source file was found")
    candidates = [pd.read_csv(path, low_memory=False) for path in files]
    source = max(candidates, key=len)
    rename = {locate_column(source.columns, choices): target for target, choices in ALIASES.items()}
    data = prepare_upworthy_frame(source.rename(columns=rename)[list(rename.values())])
    data["leakage_component"] = leakage_components(data)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    data.to_parquet(args.output, index=False)


if __name__ == "__main__":
    main()
