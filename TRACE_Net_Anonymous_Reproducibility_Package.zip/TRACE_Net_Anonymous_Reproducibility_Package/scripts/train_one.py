from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from trace_net.runner import fit_fold_seed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--fold", type=int, choices=range(1, 6), required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    configuration = yaml.safe_load(args.config.read_text())
    data_path = Path("data/processed/upworthy.parquet")
    split_path = Path("data/processed/splits/outer_folds.parquet")
    if not data_path.exists() or not split_path.exists():
        raise FileNotFoundError("processed data and outer-fold assignments are required")
    run = fit_fold_seed(configuration, args.fold, args.seed, data_path, split_path, Path("runs"))
    print(run)


if __name__ == "__main__":
    main()
