from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    news_path = next(args.input.rglob("news.tsv"))
    behaviors_path = next(args.input.rglob("behaviors.tsv"))
    news = pd.read_csv(news_path, sep="\t", header=None, names=["news_id", "category", "subcategory", "title", "abstract", "url", "title_entities", "abstract_entities"])
    behaviors = pd.read_csv(behaviors_path, sep="\t", header=None, names=["impression_id", "user_id", "time", "history", "impressions"])
    rows = []
    for record in behaviors.itertuples(index=False):
        for token in str(record.impressions).split():
            news_id, label = token.rsplit("-", 1)
            rows.append((record.impression_id, record.user_id, record.time, news_id, int(label)))
    exposures = pd.DataFrame(rows, columns=["impression_id", "user_id", "time", "news_id", "label"])
    args.output.mkdir(parents=True, exist_ok=True)
    news.to_parquet(args.output / "news.parquet", index=False)
    exposures.to_parquet(args.output / "exposures.parquet", index=False)


if __name__ == "__main__":
    main()
