from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def require_equal(name: str, actual: int, expected: int) -> None:
    if int(actual) != int(expected):
        raise AssertionError(f"{name}: observed {actual}, expected {expected}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--upworthy", type=Path, required=True)
    parser.add_argument("--mind", type=Path, required=True)
    args = parser.parse_args()
    expected = json.loads(Path("manifests/expected_counts.json").read_text())
    upworthy = pd.read_parquet(args.upworthy)
    target = expected["upworthy_primary"]
    for name, actual in {
        "arms": len(upworthy), "tests": upworthy.test_id.nunique(), "strata": upworthy.same_image_stratum_id.nunique(),
        "clicks": upworthy.clicks.sum(), "impressions": upworthy.impressions.sum(),
    }.items():
        require_equal(f"upworthy.{name}", int(actual), target[name])
    news = pd.read_parquet(args.mind / "news.parquet")
    exposures = pd.read_parquet(args.mind / "exposures.parquet")
    target = expected["mind_small"]
    for name, actual in {"articles": len(news), "slates": exposures.impression_id.nunique(), "users": exposures.user_id.nunique(), "candidate_exposures": len(exposures), "clicked": exposures.label.sum(), "not_clicked": (1 - exposures.label).sum()}.items():
        require_equal(f"mind.{name}", int(actual), target[name])
    print("data audit passed")


if __name__ == "__main__":
    main()
