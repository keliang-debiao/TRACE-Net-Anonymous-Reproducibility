from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    required = ["outer_fold_metrics.csv", "baseline_comparison.csv", "external_validation.csv", "ablation.csv", "robustness.csv"]
    missing = [name for name in required if not (args.results / name).exists()]
    if missing:
        raise FileNotFoundError(f"report inputs are missing: {missing}")
    for name in required:
        pd.read_csv(args.results / name).to_csv(args.output / name, index=False)
    print("report tables validated and copied")


if __name__ == "__main__":
    main()
