from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from trace_net.metrics import fold_summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--input", type=Path, default=Path("runs/outer_fold_metrics.csv"))
    parser.add_argument("--output", type=Path, default=Path("runs/fold_summary.csv"))
    args = parser.parse_args()
    yaml.safe_load(args.config.read_text())
    data = pd.read_csv(args.input)
    rows = []
    for metric, frame in data.groupby("metric"):
        result = fold_summary(frame.sort_values("fold").value)
        rows.append({"metric": metric, **result})
    pd.DataFrame(rows).to_csv(args.output, index=False)


if __name__ == "__main__":
    main()
