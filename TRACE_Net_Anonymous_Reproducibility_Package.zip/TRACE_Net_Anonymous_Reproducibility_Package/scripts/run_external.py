from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from trace_net.external import run_external_zero


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    checkpoints = sorted(Path("runs/source").glob("fold-*/seed-*/checkpoint.pt"))
    if len(checkpoints) != 25:
        raise FileNotFoundError("external evaluation requires 25 locked source checkpoints")
    configuration = yaml.safe_load(args.config.read_text())
    results = run_external_zero(configuration, Path("data/processed/mind"), Path("runs"))
    print(results.to_string(index=False))


if __name__ == "__main__":
    main()
