from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from trace_net.splitting import assign_outer_folds, assert_partition_disjointness


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = pd.read_parquet(args.input)
    data["outer_fold"] = assign_outer_folds(data)
    assert_partition_disjointness(data, "outer_fold")
    args.output.mkdir(parents=True, exist_ok=True)
    data[["arm_id", "leakage_component", "outer_fold"]].to_parquet(args.output / "outer_folds.parquet", index=False)
    summary = data.groupby("outer_fold").agg(arms=("arm_id", "size"), tests=("test_id", "nunique"), strata=("same_image_stratum_id", "nunique"), clicks=("clicks", "sum"), impressions=("impressions", "sum")).reset_index()
    summary.to_csv(args.output / "outer_fold_counts.csv", index=False)
    (args.output / "split_manifest.json").write_text(json.dumps({"algorithm": "leakage_component_greedy_balance", "folds": 5, "rows": len(data)}, indent=2) + "\n")


if __name__ == "__main__":
    main()
