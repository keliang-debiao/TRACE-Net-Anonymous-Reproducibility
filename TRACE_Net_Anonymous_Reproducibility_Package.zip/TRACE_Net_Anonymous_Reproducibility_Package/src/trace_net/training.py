from __future__ import annotations

import hashlib
import json
import random
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch

from .losses import beta_binomial_count_nll, pairwise_rank_loss, temporal_log_ratio_loss


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)


def train_epoch(model, loader, optimizer, scheduler, scaler, device, lambda_rank: float, lambda_temporal: float, lambda_groupdro: float, gradient_accumulation: int, gradient_clip_norm: float, groupdro=None):
    model.train()
    optimizer.zero_grad(set_to_none=True)
    totals = {"loss": 0.0, "count": 0.0, "rank": 0.0, "temporal": 0.0, "batches": 0}
    for step, batch in enumerate(loader, start=1):
        batch = {key: value.to(device) if hasattr(value, "to") else value for key, value in batch.items()}
        with torch.autocast(device_type="cuda", enabled=device.startswith("cuda")):
            output = model(batch["input_ids"], batch["attention_mask"], batch["numeric"], batch["set_mask"], batch["time"], batch["anchor_summary"], batch["support_flag"])
            valid = batch["set_mask"]
            count_values = beta_binomial_count_nll(batch["clicks"][valid], batch["impressions"][valid], output.probability[valid], output.concentration[valid], reduction="none")
            count = count_values.mean()
            rank = pairwise_rank_loss(output.score, batch["empirical_ctr"], batch["set_mask"])
            temporal = temporal_log_ratio_loss(output.log_temporal_ratio, batch["temporal_ratio"], batch["temporal_inverse_variance"], batch["support_flag"])
            robust = count * 0.0
            if groupdro is not None:
                group_values = []
                for group_index in range(4):
                    set_selection = batch["exposure_group"] == group_index
                    arm_selection = valid & set_selection.unsqueeze(1)
                    values = beta_binomial_count_nll(batch["clicks"][arm_selection], batch["impressions"][arm_selection], output.probability[arm_selection], output.concentration[arm_selection], reduction="none")
                    group_values.append(values.mean() if values.numel() else count.detach())
                robust = groupdro.aggregate(torch.stack(group_values))
            loss = (count + lambda_rank * rank + lambda_temporal * temporal + lambda_groupdro * robust) / gradient_accumulation
        scaler.scale(loss).backward()
        if step % gradient_accumulation == 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
            scheduler.step()
        totals["loss"] += float(loss.detach()) * gradient_accumulation
        totals["count"] += float(count.detach())
        totals["rank"] += float(rank.detach())
        totals["temporal"] += float(temporal.detach())
        totals["batches"] += 1
    return {key: value / totals["batches"] for key, value in totals.items() if key != "batches"}


@torch.no_grad()
def predict_loader(model, loader, device):
    model.eval()
    rows = []
    for batch in loader:
        identifiers = batch.pop("arm_ids")
        stratum_ids = batch.pop("stratum_ids")
        batch = {key: value.to(device) if hasattr(value, "to") else value for key, value in batch.items()}
        output = model(batch["input_ids"], batch["attention_mask"], batch["numeric"], batch["set_mask"], batch["time"], batch["anchor_summary"], batch["support_flag"])
        for set_index in range(batch["set_mask"].shape[0]):
            for arm_index in torch.where(batch["set_mask"][set_index])[0].tolist():
                rows.append({
                    "arm_id": identifiers[set_index][arm_index],
                    "same_image_stratum_id": stratum_ids[set_index],
                    "clicks": int(batch["clicks"][set_index, arm_index]),
                    "impressions": int(batch["impressions"][set_index, arm_index]),
                    "probability": float(output.probability[set_index, arm_index]),
                    "concentration": float(output.concentration[set_index, arm_index]),
                    "transported_lift": float(output.transported_lift[set_index, arm_index]),
                })
    return rows


def write_run_record(directory: Path, payload: dict) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    payload = {"utc": datetime.now(timezone.utc).isoformat(), **payload}
    with (directory / "events.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, sort_keys=True) + "\n")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()
