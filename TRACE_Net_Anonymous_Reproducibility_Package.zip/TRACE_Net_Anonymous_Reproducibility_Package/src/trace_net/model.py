from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn


@dataclass
class TraceOutput:
    probability: torch.Tensor
    concentration: torch.Tensor
    score: torch.Tensor
    log_temporal_ratio: torch.Tensor
    transported_lift: torch.Tensor


class TraceNet(nn.Module):
    """Set-conditioned evidence model with support-gated temporal transport."""

    def __init__(self, encoder_name: str = "microsoft/deberta-v3-base", numeric_features: int = 7, residual_rank: int = 64, time_hidden: int = 64, dropout: float = 0.10):
        super().__init__()
        from transformers import AutoModel

        self.encoder = AutoModel.from_pretrained(encoder_name)
        hidden = int(self.encoder.config.hidden_size)
        for parameter in self.encoder.parameters():
            parameter.requires_grad = False
        layers = self.encoder.encoder.layer
        for layer in layers[-4:]:
            for name, parameter in layer.named_parameters():
                if "query_proj" in name or "value_proj" in name:
                    parameter.requires_grad = True
        self.numeric = nn.Sequential(nn.LayerNorm(numeric_features), nn.Linear(numeric_features, 32), nn.GELU())
        joint = hidden + 32
        self.residual = nn.Sequential(nn.Linear(joint, residual_rank), nn.GELU(), nn.Linear(residual_rank, joint))
        self.dropout = nn.Dropout(dropout)
        self.mean_head = nn.Linear(joint, 1)
        self.concentration_head = nn.Linear(joint, 1)
        self.rank_head = nn.Linear(joint, 1)
        self.time_network = nn.Sequential(nn.Linear(8, time_hidden), nn.GELU(), nn.Dropout(dropout), nn.Linear(time_hidden, 1))

    def forward(self, input_ids, attention_mask, numeric, set_mask, source_target_time, anchor_summary, support_flag) -> TraceOutput:
        batch, arms, tokens = input_ids.shape
        encoded = self.encoder(input_ids=input_ids.reshape(-1, tokens), attention_mask=attention_mask.reshape(-1, tokens)).last_hidden_state[:, 0]
        encoded = encoded.reshape(batch, arms, -1)
        numeric_encoded = self.numeric(numeric)
        joint = torch.cat([encoded, numeric_encoded], dim=-1)
        weights = set_mask.unsqueeze(-1).to(joint.dtype)
        center = (joint * weights).sum(dim=1, keepdim=True) / weights.sum(dim=1, keepdim=True).clamp_min(1.0)
        representation = self.dropout(joint + self.residual((joint - center) * weights))
        probability = torch.sigmoid(self.mean_head(representation).squeeze(-1))
        concentration = torch.nn.functional.softplus(self.concentration_head(representation).squeeze(-1)) + 1e-4
        score = self.rank_head(representation).squeeze(-1)
        temporal_input = torch.cat([source_target_time, anchor_summary], dim=-1)
        log_ratio = self.time_network(temporal_input).squeeze(-1)
        raw_lift = probability - (probability * weights.squeeze(-1)).sum(1, keepdim=True) / weights.squeeze(-1).sum(1, keepdim=True).clamp_min(1.0)
        ratio = torch.exp(log_ratio).unsqueeze(-1)
        supported = support_flag.to(raw_lift.dtype).unsqueeze(-1)
        transported = raw_lift * (supported * ratio + (1.0 - supported))
        return TraceOutput(probability, concentration, score, log_ratio, transported)


def apply_lora(model: TraceNet, rank: int = 16, alpha: int = 32, dropout: float = 0.10) -> TraceNet:
    from peft import LoraConfig, get_peft_model

    layer_count = int(model.encoder.config.num_hidden_layers)
    configuration = LoraConfig(
        r=rank,
        lora_alpha=alpha,
        lora_dropout=dropout,
        target_modules=["query_proj", "value_proj"],
        layers_to_transform=list(range(layer_count - 4, layer_count)),
        bias="none",
    )
    model.encoder = get_peft_model(model.encoder, configuration)
    return model
