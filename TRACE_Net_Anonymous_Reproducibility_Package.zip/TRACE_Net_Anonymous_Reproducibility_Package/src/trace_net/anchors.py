from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


Z_90 = 1.6448536269514722


@dataclass(frozen=True)
class AnchorRule:
    minimum_distinct_tests_each_period: int = 2
    minimum_impressions_each_period: int = 1000
    propensity_floor: float = 0.01
    folds: int = 5


def effective_sample_size(weights: np.ndarray) -> float:
    weights = np.asarray(weights, dtype=np.float64)
    return float(weights.sum() ** 2 / np.square(weights).sum())


def _weighted_dr_mean(outcome, period, period_value, outcome_prediction, propensity_target, weights, propensity_floor):
    y = np.asarray(outcome, dtype=np.float64)
    d = np.asarray(period, dtype=np.int64)
    mu = np.asarray(outcome_prediction, dtype=np.float64)
    e = np.clip(np.asarray(propensity_target, dtype=np.float64), propensity_floor, 1.0 - propensity_floor)
    w = np.asarray(weights, dtype=np.float64)
    probability = e if period_value == 1 else 1.0 - e
    influence_value = mu + (d == period_value) * (y - mu) / probability
    normalized = w / w.sum()
    estimate = float(np.sum(normalized * influence_value))
    centered = influence_value - estimate
    n_eff = effective_sample_size(w)
    variance = float(np.sum(normalized * centered**2) / max(n_eff - 1.0, 1.0))
    return estimate, variance**0.5


def cross_fitted_nuisance(frame: pd.DataFrame, covariates: list[str], group_column: str, period_column: str, outcome_column: str, weight_column: str, folds: int = 5) -> pd.DataFrame:
    from lightgbm import LGBMRegressor
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import GroupKFold

    data = frame.copy()
    data["propensity_target"] = np.nan
    data["outcome_source"] = np.nan
    data["outcome_target"] = np.nan
    splitter = GroupKFold(n_splits=folds)
    groups = data[group_column].astype(str).to_numpy()
    x = data[covariates].to_numpy(dtype=np.float64)
    d = data[period_column].to_numpy(dtype=np.int64)
    y = data[outcome_column].to_numpy(dtype=np.float64)
    w = data[weight_column].to_numpy(dtype=np.float64)
    for train, held in splitter.split(x, d, groups):
        propensity = LogisticRegression(C=1.0, penalty="l2", solver="lbfgs", max_iter=2000, random_state=0)
        propensity.fit(x[train], d[train], sample_weight=w[train])
        data.iloc[held, data.columns.get_loc("propensity_target")] = propensity.predict_proba(x[held])[:, 1]
        for period_value, output_column in ((0, "outcome_source"), (1, "outcome_target")):
            period_train = train[d[train] == period_value]
            model = LGBMRegressor(n_estimators=500, learning_rate=0.03, num_leaves=31, random_state=0, verbosity=-1)
            model.fit(x[period_train], y[period_train], sample_weight=w[period_train])
            data.iloc[held, data.columns.get_loc(output_column)] = model.predict(x[held])
    if data[["propensity_target", "outcome_source", "outcome_target"]].isna().any().any():
        raise RuntimeError("cross-fitted nuisance predictions are incomplete")
    return data


def summarize_anchor_tuple(frame: pd.DataFrame, rule: AnchorRule = AnchorRule()) -> dict[str, float | bool]:
    required = {"period", "test_id", "impressions", "log_effect", "propensity_target", "outcome_source", "outcome_target"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"missing anchor columns: {sorted(missing)}")
    counts = frame.groupby("period").agg(tests=("test_id", "nunique"), impressions=("impressions", "sum"))
    if set(counts.index.tolist()) != {0, 1}:
        return {"eligible": False, "reason": "period_recurrence"}
    if (counts["tests"] < rule.minimum_distinct_tests_each_period).any():
        return {"eligible": False, "reason": "test_count"}
    if (counts["impressions"] < rule.minimum_impressions_each_period).any():
        return {"eligible": False, "reason": "exposure"}
    estimates = []
    for period_value, prediction_column in ((0, "outcome_source"), (1, "outcome_target")):
        estimate, standard_error = _weighted_dr_mean(
            frame["log_effect"], frame["period"], period_value, frame[prediction_column],
            frame["propensity_target"], frame["impressions"], rule.propensity_floor,
        )
        estimates.append((estimate, standard_error))
    source, target = estimates
    intervals = [(value - Z_90 * se, value + Z_90 * se) for value, se in estimates]
    nonzero = all(low > 0 or high < 0 for low, high in intervals)
    same_sign = np.sign(source[0]) == np.sign(target[0]) and source[0] != 0 and target[0] != 0
    if not (nonzero and same_sign):
        return {"eligible": False, "reason": "sign_interval", "source": source[0], "target": target[0]}
    ratio = abs(target[0] / source[0])
    variance = (target[1] / abs(target[0])) ** 2 + (source[1] / abs(source[0])) ** 2
    return {
        "eligible": True,
        "reason": "eligible",
        "source": source[0],
        "source_se": source[1],
        "target": target[0],
        "target_se": target[1],
        "ratio": ratio,
        "log_ratio": float(np.log(ratio)),
        "log_ratio_variance": float(variance),
    }
