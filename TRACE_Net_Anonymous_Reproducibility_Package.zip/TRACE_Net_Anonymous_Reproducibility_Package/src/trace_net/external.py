from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from torch.utils.data import DataLoader
from transformers import AutoTokenizer

from .conformal import binary_prediction_sets
from .data import common_baseline_numeric
from .datasets import NUMERIC_COLUMNS, StratumCollator, StratumDataset
from .metrics import balanced_selective_risk
from .model import TraceNet, apply_lora
from .training import predict_loader


def prepare_mind_frame(processed_root: Path, checkpoint: dict) -> pd.DataFrame:
    news = pd.read_parquet(processed_root / "news.parquet")
    exposures = pd.read_parquet(processed_root / "exposures.parquet")
    data = exposures.merge(news[["news_id", "title", "abstract"]], on="news_id", how="left", validate="many_to_one")
    data["arm_id"] = data.impression_id.astype(str) + "::" + data.news_id.astype(str)
    data["same_image_stratum_id"] = data.impression_id.astype(str)
    data["headline"] = data.title.fillna("")
    data["supporting_text"] = data.abstract
    data["clicks"] = data.label.astype(int)
    data["impressions"] = 1
    data["started_at"] = pd.to_datetime(data.time, utc=True)
    data["calendar_quarter"] = data.started_at.dt.to_period("Q").astype(str)
    numeric = common_baseline_numeric(data, pd.Timestamp(checkpoint["platform_origin"]))
    numeric = numeric.rename(columns={"platform_age": "standardized_platform_age"})
    scaled = ["headline_token_count", "supporting_text_token_count", "standardized_platform_age", "candidate_set_size"]
    numeric.loc[:, scaled] = (numeric[scaled].to_numpy() - np.asarray(checkpoint["scaler_mean"])) / np.asarray(checkpoint["scaler_scale"])
    for column in NUMERIC_COLUMNS:
        data[column] = numeric[column].astype(float)
    data["source_time"] = 0.0
    data["target_time"] = 0.0
    data["transport_supported"] = False
    data["temporal_ratio"] = 1.0
    data["temporal_inverse_variance"] = 0.0
    data["exposure_group"] = 0
    for index in range(6):
        data[f"anchor_feature_{index}"] = 0.0
    return data


def _ece(labels, probabilities, bins=15):
    labels = np.asarray(labels)
    probabilities = np.asarray(probabilities)
    edges = np.unique(np.quantile(probabilities, np.linspace(0, 1, bins + 1)))
    if len(edges) < 2:
        return 0.0
    assignment = np.clip(np.digitize(probabilities, edges[1:-1], right=True), 0, len(edges) - 2)
    value = 0.0
    for index in range(len(edges) - 1):
        selected = assignment == index
        if selected.any():
            value += selected.mean() * abs(labels[selected].mean() - probabilities[selected].mean())
    return float(value)


def _ranking_metrics(frame):
    reciprocal, ndcg = [], []
    for _, slate in frame.groupby("same_image_stratum_id", sort=False):
        ordered = slate.sort_values(["probability", "arm_id"], ascending=[False, True]).label.to_numpy(dtype=int)
        relevant = np.flatnonzero(ordered == 1)
        reciprocal.append(0.0 if len(relevant) == 0 else 1.0 / (relevant[0] + 1.0))
        weights = 1.0 / np.log2(np.arange(2, min(len(ordered), 10) + 2))
        dcg = float((ordered[:10] * weights).sum())
        ideal = float(weights[: min(int(ordered.sum()), 10)].sum())
        ndcg.append(0.0 if ideal == 0 else dcg / ideal)
    return float(np.mean(reciprocal)), float(np.mean(ndcg))


def evaluate_external_predictions(frame: pd.DataFrame, quantile: float, tau: float, gamma: float) -> dict[str, float]:
    labels = frame.label.to_numpy(dtype=int)
    probabilities = frame.probability.to_numpy(dtype=float)
    prediction_sets = binary_prediction_sets(probabilities, quantile)
    coverage = np.mean([int(label in prediction_set) for label, prediction_set in zip(labels, prediction_sets)])
    set_size = np.mean([len(prediction_set) for prediction_set in prediction_sets])
    selective = balanced_selective_risk(labels, probabilities, tau, gamma)
    mrr, ndcg = _ranking_metrics(frame)
    return {
        "roc_auc": float(roc_auc_score(labels, probabilities)),
        "pr_auc": float(average_precision_score(labels, probabilities)),
        "mrr": mrr, "ndcg10": ndcg,
        "brier": float(brier_score_loss(labels, probabilities)), "ece15": _ece(labels, probabilities),
        "prediction_set_coverage": float(coverage), "set_size": float(set_size),
        "balanced_selective_risk": selective["risk"], "retained_fraction": selective["retained_fraction"],
    }


def run_external_zero(configuration: dict, processed_root: Path, runs_root: Path) -> pd.DataFrame:
    model_configuration = configuration["model"]
    device = "cuda" if torch.cuda.is_available() else "cpu"
    tokenizer = AutoTokenizer.from_pretrained(model_configuration["encoder"])
    result_rows = []
    for fold in range(1, 6):
        summed = None
        base = None
        quantiles, thresholds, margins = [], [], []
        for seed in configuration["study"]["seeds"]:
            checkpoint_path = runs_root / "source" / f"fold-{fold}" / f"seed-{seed}" / "checkpoint.pt"
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
            data = prepare_mind_frame(processed_root, checkpoint)
            loader = DataLoader(StratumDataset(data), batch_size=model_configuration["set_batch_size"], shuffle=False, num_workers=0, collate_fn=StratumCollator(tokenizer))
            model = apply_lora(TraceNet(model_configuration["encoder"], 7, model_configuration["residual_rank"], model_configuration["time_hidden"], model_configuration["dropout"]),
                               model_configuration["lora"]["rank"], model_configuration["lora"]["alpha"], model_configuration["lora"]["dropout"]).to(device)
            model.load_state_dict(checkpoint["state_dict"])
            predicted = pd.DataFrame(predict_loader(model, loader, device)).sort_values("arm_id").reset_index(drop=True)
            if base is None:
                base = data[["arm_id", "label", "same_image_stratum_id"]].sort_values("arm_id").reset_index(drop=True)
                summed = np.zeros(len(base), dtype=float)
            if not np.array_equal(predicted.arm_id.to_numpy(), base.arm_id.to_numpy()):
                raise AssertionError("external prediction identifiers are misaligned")
            probability = np.clip(predicted.probability.to_numpy(), 1e-7, 1.0 - 1e-7)
            logits = np.log(probability / (1.0 - probability))
            probability = 1.0 / (1.0 + np.exp(-logits / float(checkpoint["temperature"])))
            summed += probability
            quantiles.append(float(checkpoint["binary_quantile"]))
            thresholds.append(float(checkpoint["operating_point"]["tau"]))
            margins.append(float(checkpoint["operating_point"]["gamma"]))
        base["probability"] = summed / len(configuration["study"]["seeds"])
        metrics = evaluate_external_predictions(base, float(np.mean(quantiles)), float(np.mean(thresholds)), float(np.mean(margins)))
        base.to_parquet(runs_root / f"external_0_fold_{fold}.parquet", index=False)
        result_rows.append({"fold": fold, **metrics})
    results = pd.DataFrame(result_rows)
    results.to_csv(runs_root / "external_0_metrics.csv", index=False)
    return results
