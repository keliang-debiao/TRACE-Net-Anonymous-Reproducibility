from __future__ import annotations

import itertools

import numpy as np
import pandas as pd

from .anchors import AnchorRule, cross_fitted_nuisance, summarize_anchor_tuple


def _logit(value):
    value = np.clip(value, 1e-7, 1.0 - 1e-7)
    return np.log(value / (1.0 - value))


def arm_log_effects(frame: pd.DataFrame) -> pd.Series:
    smoothed = (frame.clicks.to_numpy(dtype=float) + 0.5) / (frame.impressions.to_numpy(dtype=float) + 1.0)
    logits = pd.Series(_logit(smoothed), index=frame.index)
    effects = pd.Series(index=frame.index, dtype=float)
    for _, group in frame.groupby("same_image_stratum_id", sort=False):
        for index in group.index:
            others = group.index[group.index != index]
            weights = frame.loc[others, "impressions"].to_numpy(dtype=float)
            effects.loc[index] = logits.loc[index] - np.average(logits.loc[others], weights=weights)
    return effects


def build_fold_anchor_table(model_frame: pd.DataFrame, covariates: list[str], rule: AnchorRule = AnchorRule()) -> pd.DataFrame:
    data = model_frame.copy()
    data["log_effect"] = arm_log_effects(data)
    key_columns = ["normalized_headline", "normalized_context", "eyecatcher_id"]
    quarters = sorted(data.calendar_quarter.unique().tolist())
    records = []
    for source, target in itertools.combinations(quarters, 2):
        pair = data.loc[data.calendar_quarter.isin([source, target])].copy()
        recurrent = pair.groupby(key_columns).calendar_quarter.nunique()
        keys = recurrent[recurrent == 2].index
        if len(keys) == 0:
            continue
        pair["period"] = (pair.calendar_quarter == target).astype(int)
        pair["anchor_group"] = pair[key_columns].astype(str).agg("::".join, axis=1)
        eligible_rows = pair.set_index(key_columns).loc[keys].reset_index()
        if eligible_rows.anchor_group.nunique() < rule.folds:
            continue
        fitted = cross_fitted_nuisance(eligible_rows, covariates, "anchor_group", "period", "log_effect", "impressions", rule.folds)
        for key, group in fitted.groupby(key_columns, sort=False):
            result = summarize_anchor_tuple(group, rule)
            if result["eligible"]:
                records.append({
                    **dict(zip(key_columns, key)), "source_quarter": source, "target_quarter": target,
                    "source_effect": result["source"], "source_se": result["source_se"],
                    "target_effect": result["target"], "target_se": result["target_se"],
                    "temporal_ratio": result["ratio"], "log_ratio_variance": result["log_ratio_variance"],
                    "distinct_tests_source": int(group.loc[group.period == 0, "test_id"].nunique()),
                    "distinct_tests_target": int(group.loc[group.period == 1, "test_id"].nunique()),
                    "impressions_source": int(group.loc[group.period == 0, "impressions"].sum()),
                    "impressions_target": int(group.loc[group.period == 1, "impressions"].sum()),
                })
    output = pd.DataFrame(records)
    if len(output):
        low, high = output.temporal_ratio.quantile([0.01, 0.99])
        output["temporal_ratio"] = output.temporal_ratio.clip(low, high)
        cap = output.log_ratio_variance.replace(0, np.nan).rpow(-1).quantile(0.95)
        output["inverse_variance"] = output.log_ratio_variance.replace(0, np.nan).rpow(-1).clip(upper=cap).fillna(cap)
    return output


def attach_anchor_support(frame: pd.DataFrame, anchors: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    data["target_quarter"] = data.calendar_quarter
    key = ["normalized_headline", "normalized_context", "eyecatcher_id", "target_quarter"]
    if len(anchors):
        merged = data.merge(anchors, on=key, how="left")
        merged = merged.sort_values("source_quarter").groupby("arm_id", as_index=False).tail(1).set_index("arm_id")
        data = data.set_index("arm_id")
        columns = ["source_quarter", "source_effect", "source_se", "target_effect", "target_se", "temporal_ratio", "log_ratio_variance", "inverse_variance"]
        for column in columns:
            data[column] = merged[column]
        data = data.reset_index()
    data["transport_supported"] = data.get("temporal_ratio", pd.Series(index=data.index, dtype=float)).notna()
    ratio = data["temporal_ratio"] if "temporal_ratio" in data else pd.Series(1.0, index=data.index)
    variance_weight = data["inverse_variance"] if "inverse_variance" in data else pd.Series(0.0, index=data.index)
    data["temporal_ratio"] = ratio.fillna(1.0)
    data["temporal_inverse_variance"] = variance_weight.fillna(0.0)
    quarter_order = {value: index for index, value in enumerate(sorted(frame.calendar_quarter.unique()))}
    data["target_time"] = data.calendar_quarter.map(quarter_order).astype(float) / max(len(quarter_order) - 1, 1)
    data["source_time"] = data.get("source_quarter", data.calendar_quarter).fillna(data.calendar_quarter).map(quarter_order).fillna(0).astype(float) / max(len(quarter_order) - 1, 1)
    feature_sources = ["source_effect", "source_se", "target_effect", "target_se", "log_ratio_variance"]
    for index, column in enumerate(feature_sources):
        values = data[column] if column in data else pd.Series(0.0, index=data.index)
        data[f"anchor_feature_{index}"] = values.fillna(0.0)
    data["anchor_feature_5"] = data.transport_supported.astype(float)
    return data
