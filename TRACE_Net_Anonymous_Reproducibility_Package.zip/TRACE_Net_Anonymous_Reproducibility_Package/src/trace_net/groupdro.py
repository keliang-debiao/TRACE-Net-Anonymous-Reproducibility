from __future__ import annotations

import torch


class GroupDRO:
    def __init__(self, groups: int, step_size: float = 0.01, device: str = "cpu"):
        self.weights = torch.ones(groups, device=device) / groups
        self.step_size = step_size

    def aggregate(self, group_losses: torch.Tensor) -> torch.Tensor:
        if group_losses.shape != self.weights.shape:
            raise ValueError("group-loss vector has the wrong shape")
        with torch.no_grad():
            self.weights *= torch.exp(self.step_size * group_losses.detach())
            self.weights /= self.weights.sum()
        return torch.sum(self.weights * group_losses)
