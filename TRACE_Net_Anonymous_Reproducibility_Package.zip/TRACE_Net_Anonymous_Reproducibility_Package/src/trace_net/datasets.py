from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


NUMERIC_COLUMNS = [
    "headline_token_count", "supporting_text_token_count", "supporting_text_missing",
    "week_of_year_sine", "week_of_year_cosine", "standardized_platform_age", "candidate_set_size",
]


class StratumDataset(Dataset):
    def __init__(self, frame: pd.DataFrame):
        self.groups = [group.reset_index(drop=True) for _, group in frame.groupby("same_image_stratum_id", sort=True)]

    def __len__(self):
        return len(self.groups)

    def __getitem__(self, index):
        return self.groups[index]


@dataclass
class StratumCollator:
    tokenizer: object
    max_length: int = 128

    def __call__(self, groups: list[pd.DataFrame]) -> dict[str, torch.Tensor | list[str]]:
        batch = len(groups)
        width = max(len(group) for group in groups)
        flat_headlines, flat_contexts, positions = [], [], []
        for row_index, group in enumerate(groups):
            for arm_index, row in group.iterrows():
                flat_headlines.append(str(row.headline))
                flat_contexts.append("[missing]" if pd.isna(row.supporting_text) else str(row.supporting_text))
                positions.append((row_index, arm_index))
        encoded = self.tokenizer(flat_headlines, flat_contexts, padding=True, truncation=True, max_length=self.max_length, return_tensors="pt")
        tokens = encoded["input_ids"].shape[-1]
        input_ids = torch.full((batch, width, tokens), int(self.tokenizer.pad_token_id), dtype=torch.long)
        attention_mask = torch.zeros((batch, width, tokens), dtype=torch.long)
        numeric = torch.zeros((batch, width, len(NUMERIC_COLUMNS)), dtype=torch.float32)
        clicks = torch.zeros((batch, width), dtype=torch.float32)
        impressions = torch.ones((batch, width), dtype=torch.float32)
        empirical_ctr = torch.zeros((batch, width), dtype=torch.float32)
        set_mask = torch.zeros((batch, width), dtype=torch.bool)
        arm_ids = [[""] * width for _ in range(batch)]
        for flat_index, (row_index, arm_index) in enumerate(positions):
            row = groups[row_index].iloc[arm_index]
            input_ids[row_index, arm_index] = encoded["input_ids"][flat_index]
            attention_mask[row_index, arm_index] = encoded["attention_mask"][flat_index]
            numeric[row_index, arm_index] = torch.tensor(row[NUMERIC_COLUMNS].to_numpy(dtype=np.float32))
            clicks[row_index, arm_index] = float(row.clicks)
            impressions[row_index, arm_index] = float(row.impressions)
            empirical_ctr[row_index, arm_index] = float(row.clicks) / float(row.impressions)
            set_mask[row_index, arm_index] = True
            arm_ids[row_index][arm_index] = str(row.arm_id)
        time = torch.tensor([[float(group.iloc[0].source_time), float(group.iloc[0].target_time)] for group in groups], dtype=torch.float32)
        anchor_summary = torch.tensor([group.iloc[0][[f"anchor_feature_{index}" for index in range(6)]].to_numpy(dtype=np.float32) for group in groups])
        support_flag = torch.tensor([bool(group.iloc[0].transport_supported) for group in groups], dtype=torch.bool)
        temporal_ratio = torch.tensor([float(group.iloc[0].temporal_ratio) for group in groups], dtype=torch.float32)
        temporal_inverse_variance = torch.tensor([float(group.iloc[0].temporal_inverse_variance) for group in groups], dtype=torch.float32)
        exposure_group = torch.tensor([int(group.iloc[0].exposure_group) for group in groups], dtype=torch.long)
        return {
            "input_ids": input_ids, "attention_mask": attention_mask, "numeric": numeric,
            "clicks": clicks, "impressions": impressions, "empirical_ctr": empirical_ctr,
            "set_mask": set_mask, "time": time, "anchor_summary": anchor_summary,
            "support_flag": support_flag, "temporal_ratio": temporal_ratio,
            "temporal_inverse_variance": temporal_inverse_variance, "exposure_group": exposure_group,
            "arm_ids": arm_ids,
            "stratum_ids": [str(group.iloc[0].same_image_stratum_id) for group in groups],
        }
