from __future__ import annotations

import numpy as np


def weighted_quantile(values, weights, level: float) -> float:
    values = np.asarray(values, dtype=np.float64)
    weights = np.asarray(weights, dtype=np.float64)
    if values.shape != weights.shape or values.ndim != 1:
        raise ValueError("values and weights must be aligned one-dimensional arrays")
    if not 0.0 < level <= 1.0 or np.any(weights < 0) or weights.sum() <= 0:
        raise ValueError("invalid quantile inputs")
    order = np.argsort(values, kind="stable")
    cumulative = np.cumsum(weights[order]) / weights.sum()
    position = min(int(np.searchsorted(cumulative, level, side="left")), len(values) - 1)
    return float(values[order[position]])


def lift_interval(point_prediction, calibration_truth, calibration_prediction, calibration_weights, coverage: float = 0.90):
    scores = np.abs(np.asarray(calibration_truth) - np.asarray(calibration_prediction))
    quantile = weighted_quantile(scores, calibration_weights, coverage)
    point = np.asarray(point_prediction, dtype=np.float64)
    return point - quantile, point + quantile, quantile


def binary_lac_quantile(labels, probabilities, weights, coverage: float = 0.90) -> float:
    labels = np.asarray(labels, dtype=np.int64)
    probabilities = np.asarray(probabilities, dtype=np.float64)
    true_probability = np.where(labels == 1, probabilities, 1.0 - probabilities)
    return weighted_quantile(1.0 - true_probability, weights, coverage)


def binary_prediction_sets(probabilities, quantile: float) -> list[tuple[int, ...]]:
    probabilities = np.asarray(probabilities, dtype=np.float64)
    sets = []
    for p in probabilities:
        labels = []
        tolerance = 1e-12
        if p <= quantile + tolerance:
            labels.append(0)
        if 1.0 - p <= quantile + tolerance:
            labels.append(1)
        sets.append(tuple(labels))
    return sets
