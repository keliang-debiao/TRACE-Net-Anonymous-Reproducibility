from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold

from .conformal import weighted_quantile
from .metrics import select_operating_point


def cross_fitted_density_ratio(source_covariates, target_covariates, source_groups, target_groups, folds: int = 5, lower: float = 0.1, upper: float = 10.0):
    source = np.asarray(source_covariates, dtype=float)
    target = np.asarray(target_covariates, dtype=float)
    features = np.vstack([source, target])
    domain = np.concatenate([np.zeros(len(source), dtype=int), np.ones(len(target), dtype=int)])
    groups = np.concatenate([np.asarray(source_groups).astype(str), np.char.add("target::", np.asarray(target_groups).astype(str))])
    probability = np.empty(len(features), dtype=float)
    splitter = GroupKFold(n_splits=folds)
    for training, held in splitter.split(features, domain, groups):
        model = LogisticRegression(C=1.0, penalty="l2", solver="lbfgs", max_iter=2000, random_state=0)
        model.fit(features[training], domain[training])
        probability[held] = model.predict_proba(features[held])[:, 1]
    source_probability = np.clip(probability[: len(source)], 1e-6, 1.0 - 1e-6)
    prior_correction = len(source) / len(target)
    ratio = source_probability / (1.0 - source_probability) * prior_correction
    return np.clip(ratio, lower, upper)


def weighted_source_binary_quantile(calibration: pd.DataFrame, density_ratio, coverage: float = 0.90) -> float:
    probability = calibration.probability.to_numpy(dtype=float)
    clicks = calibration.clicks.to_numpy(dtype=float)
    impressions = calibration.impressions.to_numpy(dtype=float)
    ratio = np.asarray(density_ratio, dtype=float)
    scores = np.concatenate([1.0 - probability, probability])
    weights = np.concatenate([clicks * ratio, (impressions - clicks) * ratio])
    return weighted_quantile(scores, weights, coverage)


def audited_binary_calibration(audit_labels, audit_probabilities, coverage: float = 0.90, retained_floor: float = 0.60):
    labels = np.asarray(audit_labels, dtype=int)
    probability = np.asarray(audit_probabilities, dtype=float)
    scores = 1.0 - np.where(labels == 1, probability, 1.0 - probability)
    quantile = weighted_quantile(scores, np.ones(len(scores)), coverage)
    operating = select_operating_point(labels, probability, np.linspace(0.001, 0.100, 200), np.linspace(0.000, 0.100, 201), retained_floor)
    return {"binary_quantile": quantile, **operating}
