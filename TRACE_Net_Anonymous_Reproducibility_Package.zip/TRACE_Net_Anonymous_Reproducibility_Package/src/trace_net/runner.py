from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, get_cosine_schedule_with_warmup

from .conformal import weighted_quantile
from .data import common_baseline_numeric
from .datasets import NUMERIC_COLUMNS, StratumCollator, StratumDataset
from .groupdro import GroupDRO
from .losses import bb_enll_nats_per_impression
from .model import TraceNet, apply_lora
from .temporal import attach_anchor_support, build_fold_anchor_table
from .training import predict_loader, seed_everything, train_epoch, write_run_record


def _group_split(frame: pd.DataFrame, fraction: float, random_state: int):
    splitter = GroupShuffleSplit(n_splits=1, test_size=fraction, random_state=random_state)
    left, right = next(splitter.split(frame, groups=frame.leakage_component))
    return frame.iloc[left].copy(), frame.iloc[right].copy()


def _add_numeric_features(all_data: pd.DataFrame, fitting_index: pd.Index):
    origin = all_data.loc[fitting_index, "started_at"].min()
    numeric = common_baseline_numeric(all_data, origin)
    numeric = numeric.rename(columns={"platform_age": "standardized_platform_age"})
    scaler = StandardScaler().fit(numeric.loc[fitting_index, ["headline_token_count", "supporting_text_token_count", "standardized_platform_age", "candidate_set_size"]])
    scaled_columns = ["headline_token_count", "supporting_text_token_count", "standardized_platform_age", "candidate_set_size"]
    numeric.loc[:, scaled_columns] = scaler.transform(numeric[scaled_columns])
    for column in NUMERIC_COLUMNS:
        all_data[column] = numeric[column].astype(float)
    return scaler, origin


def _add_exposure_groups(data: pd.DataFrame, fitting_index: pd.Index):
    totals = data.groupby("same_image_stratum_id").impressions.sum()
    fit_strata = data.loc[fitting_index, "same_image_stratum_id"].unique()
    thresholds = totals.loc[fit_strata].quantile([0.25, 0.50, 0.75]).to_numpy()
    groups = np.digitize(totals.to_numpy(), thresholds, right=True)
    mapping = dict(zip(totals.index, groups))
    data["exposure_group"] = data.same_image_stratum_id.map(mapping).astype(int)
    return thresholds


def _loader(frame, tokenizer, batch_size, shuffle):
    return DataLoader(StratumDataset(frame), batch_size=batch_size, shuffle=shuffle, num_workers=0, collate_fn=StratumCollator(tokenizer))


def _evaluate(model, loader, device):
    rows = predict_loader(model, loader, device)
    frame = pd.DataFrame(rows)
    metric = bb_enll_nats_per_impression(frame.clicks, frame.impressions, frame.probability, frame.concentration)
    return metric, frame


def _fit_source_operating_point(frame: pd.DataFrame, retained_floor: float):
    probabilities = frame.probability.to_numpy(dtype=float)
    domain_weight = frame["domain_weight"].to_numpy(dtype=float) if "domain_weight" in frame else np.ones(len(frame))
    positives = frame.clicks.to_numpy(dtype=float) * domain_weight
    negatives = (frame.impressions.to_numpy(dtype=float) - frame.clicks.to_numpy(dtype=float)) * domain_weight
    candidates = []
    for tau in np.linspace(0.001, 0.100, 200):
        prediction = probabilities >= tau
        for gamma in np.linspace(0.000, 0.100, 201):
            keep = np.abs(probabilities - tau) >= gamma
            weighted_impressions = frame.impressions.to_numpy(dtype=float) * domain_weight
            retained = float((weighted_impressions * keep).sum() / weighted_impressions.sum())
            if retained < retained_floor:
                continue
            positive_denominator = positives[keep].sum()
            negative_denominator = negatives[keep].sum()
            if positive_denominator == 0 or negative_denominator == 0:
                continue
            false_positive_rate = negatives[keep & prediction].sum() / negative_denominator
            false_negative_rate = positives[keep & ~prediction].sum() / positive_denominator
            risk = 0.5 * (false_positive_rate + false_negative_rate)
            candidates.append((risk, -retained, gamma, tau))
    if not candidates:
        raise RuntimeError("no calibration operating point satisfies the retained-fraction constraint")
    risk, negative_retained, gamma, tau = min(candidates)
    return {"tau": float(tau), "gamma": float(gamma), "risk": float(risk), "retained_fraction": float(-negative_retained)}


def _lift_truth(frame: pd.DataFrame):
    ctr = frame.clicks / frame.impressions
    center = frame.assign(ctr=ctr).groupby("same_image_stratum_id").ctr.transform("mean")
    return ctr - center


def _fit_temperature(frame: pd.DataFrame) -> float:
    from scipy.optimize import minimize_scalar

    probability = np.clip(frame.probability.to_numpy(dtype=float), 1e-7, 1.0 - 1e-7)
    logits = np.log(probability / (1.0 - probability))
    clicks = frame.clicks.to_numpy(dtype=float)
    impressions = frame.impressions.to_numpy(dtype=float)
    def objective(log_temperature):
        temperature = np.exp(log_temperature)
        calibrated = 1.0 / (1.0 + np.exp(-logits / temperature))
        calibrated = np.clip(calibrated, 1e-7, 1.0 - 1e-7)
        return float(-(clicks * np.log(calibrated) + (impressions - clicks) * np.log(1.0 - calibrated)).sum() / impressions.sum())
    result = minimize_scalar(objective, bounds=(-3.0, 3.0), method="bounded")
    if not result.success:
        raise RuntimeError("temperature fitting failed")
    return float(np.exp(result.x))


def _apply_temperature(probability, temperature):
    probability = np.clip(np.asarray(probability, dtype=float), 1e-7, 1.0 - 1e-7)
    logits = np.log(probability / (1.0 - probability))
    return 1.0 / (1.0 + np.exp(-logits / temperature))


def fit_fold_seed(configuration: dict, fold: int, seed: int, data_path: Path, split_path: Path, run_root: Path):
    seed_everything(seed)
    run = run_root / "source" / f"fold-{fold}" / f"seed-{seed}"
    run.mkdir(parents=True, exist_ok=True)
    write_run_record(run, {"event": "run_started", "protocol": "source", "fold": fold, "seed": seed})
    data = pd.read_parquet(data_path)
    split = pd.read_parquet(split_path)
    if "outer_fold" not in data:
        data = data.merge(split[["arm_id", "outer_fold"]], on="arm_id", how="left", validate="one_to_one")
    pool = data.loc[data.outer_fold != fold].copy()
    test = data.loc[data.outer_fold == fold].copy()
    model_fit, calibration = _group_split(pool, configuration["study"]["calibration_fraction"], 1000 + fold)
    training, early = _group_split(model_fit, 0.10, 2000 + fold)
    scaler, platform_origin = _add_numeric_features(data, model_fit.index)
    exposure_thresholds = _add_exposure_groups(data, model_fit.index)
    model_fit = data.loc[model_fit.index].copy()
    training = data.loc[training.index].copy()
    early = data.loc[early.index].copy()
    calibration = data.loc[calibration.index].copy()
    test = data.loc[test.index].copy()
    covariates = NUMERIC_COLUMNS
    anchors = build_fold_anchor_table(model_fit, covariates)
    for name, frame in (("training", training), ("early", early), ("calibration", calibration), ("test", test)):
        attached = attach_anchor_support(data.loc[frame.index].copy(), anchors)
        if name == "training":
            training = attached
        elif name == "early":
            early = attached
        elif name == "calibration":
            calibration = attached
        else:
            test = attached
    anchors.to_parquet(run / "eligible_anchors.parquet", index=False)
    model_configuration = configuration["model"]
    tokenizer = AutoTokenizer.from_pretrained(model_configuration["encoder"])
    loaders = {
        "training": _loader(training, tokenizer, model_configuration["set_batch_size"], True),
        "early": _loader(early, tokenizer, model_configuration["set_batch_size"], False),
        "calibration": _loader(calibration, tokenizer, model_configuration["set_batch_size"], False),
        "test": _loader(test, tokenizer, model_configuration["set_batch_size"], False),
    }
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = apply_lora(TraceNet(model_configuration["encoder"], 7, model_configuration["residual_rank"], model_configuration["time_hidden"], model_configuration["dropout"]),
                       model_configuration["lora"]["rank"], model_configuration["lora"]["alpha"], model_configuration["lora"]["dropout"]).to(device)
    encoder_parameters, head_parameters = [], []
    for name, parameter in model.named_parameters():
        if parameter.requires_grad:
            (encoder_parameters if name.startswith("encoder") else head_parameters).append(parameter)
    optimizer = torch.optim.AdamW([
        {"params": encoder_parameters, "lr": model_configuration["encoder_learning_rate"]},
        {"params": head_parameters, "lr": model_configuration["head_learning_rate"]},
    ], weight_decay=model_configuration["weight_decay"])
    updates_per_epoch = math.ceil(len(loaders["training"]) / model_configuration["gradient_accumulation"])
    total_updates = updates_per_epoch * model_configuration["maximum_epochs"]
    scheduler = get_cosine_schedule_with_warmup(optimizer, int(total_updates * model_configuration["warmup_fraction"]), total_updates)
    scaler_amp = torch.amp.GradScaler("cuda", enabled=device == "cuda")
    groupdro = GroupDRO(4, device=device)
    best, patience, best_state = float("inf"), 0, None
    for epoch in range(1, model_configuration["maximum_epochs"] + 1):
        metrics = train_epoch(model, loaders["training"], optimizer, scheduler, scaler_amp, device,
                              model_configuration["lambda_rank"], model_configuration["lambda_temporal"], model_configuration["lambda_groupdro"],
                              model_configuration["gradient_accumulation"], model_configuration["gradient_clip_norm"], groupdro)
        early_metric, _ = _evaluate(model, loaders["early"], device)
        write_run_record(run, {"event": "epoch", "epoch": epoch, **metrics, "early_bb_enll": early_metric})
        if early_metric < best:
            best, patience = early_metric, 0
            best_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
        else:
            patience += 1
            if patience >= model_configuration["early_stopping_patience"]:
                break
    if best_state is None:
        raise RuntimeError("training did not produce a checkpoint")
    model.load_state_dict(best_state)
    _, calibration_predictions = _evaluate(model, loaders["calibration"], device)
    _, test_predictions = _evaluate(model, loaders["test"], device)
    temperature = _fit_temperature(calibration_predictions)
    calibration_predictions["probability"] = _apply_temperature(calibration_predictions.probability, temperature)
    test_predictions["probability"] = _apply_temperature(test_predictions.probability, temperature)
    calibration_predictions["lift_truth"] = _lift_truth(calibration_predictions)
    scores = np.abs(calibration_predictions.lift_truth - calibration_predictions.transported_lift)
    conformal_quantile = weighted_quantile(scores, calibration_predictions.impressions, configuration["study"]["primary_coverage"])
    binary_scores = np.concatenate([1.0 - calibration_predictions.probability.to_numpy(), calibration_predictions.probability.to_numpy()])
    binary_weights = np.concatenate([calibration_predictions.clicks.to_numpy(), (calibration_predictions.impressions - calibration_predictions.clicks).to_numpy()])
    binary_quantile = weighted_quantile(binary_scores, binary_weights, configuration["study"]["primary_coverage"])
    operating_point = _fit_source_operating_point(calibration_predictions, configuration["decision"]["retain_fraction_floor"])
    calibration_predictions.to_csv(run / "calibration_predictions.csv", index=False)
    calibration[["arm_id", *NUMERIC_COLUMNS]].to_csv(run / "calibration_covariates.csv", index=False)
    test_predictions.to_csv(run / "test_predictions.csv", index=False)
    checkpoint = {
        "state_dict": best_state, "fold": fold, "seed": seed, "configuration": configuration,
        "scaler_mean": scaler.mean_, "scaler_scale": scaler.scale_, "exposure_thresholds": exposure_thresholds,
        "platform_origin": platform_origin.isoformat(),
        "temperature": temperature, "conformal_quantile": conformal_quantile, "binary_quantile": binary_quantile, "operating_point": operating_point,
    }
    torch.save(checkpoint, run / "checkpoint.pt")
    (run / "metrics.json").write_text(json.dumps({"best_early_bb_enll": best, "temperature": temperature, "conformal_quantile": conformal_quantile, "binary_quantile": binary_quantile, **operating_point}, indent=2) + "\n")
    write_run_record(run, {"event": "run_completed", "best_early_bb_enll": best, "epochs": epoch})
    return run
