from __future__ import annotations

import re
import string
import unicodedata

_BOUNDARY = string.punctuation + "“”‘’«»‹›"


def normalize_text(value: object) -> str:
    """Apply the locked exact-key text normalization."""
    if value is None:
        return "[missing]"
    text = unicodedata.normalize("NFKC", str(value)).lower()
    text = re.sub(r"\s+", " ", text).strip()
    text = text.strip(_BOUNDARY + " ")
    return text if text else "[missing]"


def temporal_key(headline: object, context: object, eyecatcher_id: object) -> tuple[str, str, str]:
    return normalize_text(headline), normalize_text(context), str(eyecatcher_id)
