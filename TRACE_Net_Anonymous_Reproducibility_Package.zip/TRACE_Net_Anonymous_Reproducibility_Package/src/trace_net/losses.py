from __future__ import annotations

from typing import Any

import numpy as np


def _numpy_beta_binomial_terms(clicks: np.ndarray, impressions: np.ndarray, probability: np.ndarray, concentration: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    from scipy.special import betaln, gammaln

    y = np.asarray(clicks, dtype=np.float64)
    n = np.asarray(impressions, dtype=np.float64)
    p = np.clip(np.asarray(probability, dtype=np.float64), 1e-7, 1.0 - 1e-7)
    k = np.maximum(np.asarray(concentration, dtype=np.float64), 1e-4)
    alpha, beta = p * k, (1.0 - p) * k
    sequence_log_probability = betaln(y + alpha, n - y + beta) - betaln(alpha, beta)
    log_combination = gammaln(n + 1.0) - gammaln(y + 1.0) - gammaln(n - y + 1.0)
    return sequence_log_probability, log_combination


def beta_binomial_count_nll(clicks: Any, impressions: Any, probability: Any, concentration: Any, reduction: str = "mean"):
    """Full beta-binomial count NLL, including the combinatorial term."""
    try:
        import torch
        if isinstance(probability, torch.Tensor):
            y = clicks.to(probability.dtype)
            n = impressions.to(probability.dtype)
            p = probability.clamp(1e-7, 1.0 - 1e-7)
            k = concentration.clamp_min(1e-4)
            alpha, beta = p * k, (1.0 - p) * k
            lbeta = lambda a, b: torch.lgamma(a) + torch.lgamma(b) - torch.lgamma(a + b)
            log_c = torch.lgamma(n + 1.0) - torch.lgamma(y + 1.0) - torch.lgamma(n - y + 1.0)
            values = -(log_c + lbeta(y + alpha, n - y + beta) - lbeta(alpha, beta))
            if reduction == "none":
                return values
            return values.sum() if reduction == "sum" else values.mean()
    except ImportError:
        pass
    seq, comb = _numpy_beta_binomial_terms(clicks, impressions, probability, concentration)
    values = -(seq + comb)
    if reduction == "none":
        return values
    return float(values.sum() if reduction == "sum" else values.mean())


def bb_enll_nats_per_impression(clicks: Any, impressions: Any, probability: Any, concentration: Any) -> float:
    """Exposure-normalized sequence NLL without the combinatorial term."""
    seq, _ = _numpy_beta_binomial_terms(clicks, impressions, probability, concentration)
    denominator = float(np.asarray(impressions, dtype=np.float64).sum())
    if denominator <= 0:
        raise ValueError("total impressions must be positive")
    return float(-seq.sum() / denominator)


def pairwise_rank_loss(scores, empirical_ctr, mask):
    import torch
    losses = []
    batch, width = scores.shape
    for b in range(batch):
        valid = torch.where(mask[b])[0]
        for left in range(len(valid)):
            for right in range(left + 1, len(valid)):
                i, j = valid[left], valid[right]
                target = (empirical_ctr[b, i] > empirical_ctr[b, j]).to(scores.dtype)
                if empirical_ctr[b, i] == empirical_ctr[b, j]:
                    continue
                losses.append(torch.nn.functional.binary_cross_entropy_with_logits(scores[b, i] - scores[b, j], target))
    return torch.stack(losses).mean() if losses else scores.sum() * 0.0


def temporal_log_ratio_loss(predicted_log_ratio, target_ratio, inverse_variance, mask):
    import torch
    valid = mask & torch.isfinite(target_ratio) & (target_ratio > 0)
    if not valid.any():
        return predicted_log_ratio.sum() * 0.0
    squared = (predicted_log_ratio[valid] - torch.log(target_ratio[valid])) ** 2
    return (squared * inverse_variance[valid]).sum() / inverse_variance[valid].sum().clamp_min(1e-8)
