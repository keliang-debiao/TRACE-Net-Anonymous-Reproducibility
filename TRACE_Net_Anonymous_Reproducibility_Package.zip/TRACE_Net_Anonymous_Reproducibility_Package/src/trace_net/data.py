from __future__ import annotations

import pandas as pd

from .normalization import normalize_text


RISK_START = pd.Timestamp("2013-06-25", tz="UTC")
RISK_END = pd.Timestamp("2014-01-11", tz="UTC")


def prepare_upworthy_frame(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"arm_id", "test_id", "eyecatcher_id", "headline", "supporting_text", "clicks", "impressions", "started_at"}
    if missing := required.difference(frame.columns):
        raise ValueError(f"missing source columns: {sorted(missing)}")
    data = frame.copy()
    data["started_at"] = pd.to_datetime(data["started_at"], utc=True, errors="raise")
    data = data.loc[~((data["started_at"] >= RISK_START) & (data["started_at"] < RISK_END))].copy()
    data["normalized_headline"] = data["headline"].map(normalize_text)
    data["normalized_context"] = data["supporting_text"].map(normalize_text)
    data["calendar_quarter"] = data["started_at"].dt.to_period("Q").astype(str)
    data["same_image_stratum_id"] = data["test_id"].astype(str) + "::" + data["eyecatcher_id"].astype(str)
    unique_headlines = data.groupby("same_image_stratum_id")["normalized_headline"].transform("nunique")
    data = data.loc[unique_headlines >= 2].copy()
    if (data["clicks"] < 0).any() or (data["impressions"] <= 0).any() or (data["clicks"] > data["impressions"]).any():
        raise ValueError("invalid click-count fields")
    return data


def common_baseline_numeric(frame: pd.DataFrame, platform_origin: pd.Timestamp) -> pd.DataFrame:
    week = frame["started_at"].dt.isocalendar().week.astype(float)
    age_days = (frame["started_at"] - platform_origin).dt.total_seconds() / 86400.0
    output = pd.DataFrame(index=frame.index)
    output["headline_token_count"] = frame["headline"].fillna("").str.split().str.len()
    output["supporting_text_token_count"] = frame["supporting_text"].fillna("").str.split().str.len()
    output["supporting_text_missing"] = frame["supporting_text"].isna().astype(float)
    output["week_of_year_sine"] = __import__("numpy").sin(2.0 * __import__("numpy").pi * week / 52.0)
    output["week_of_year_cosine"] = __import__("numpy").cos(2.0 * __import__("numpy").pi * week / 52.0)
    output["platform_age"] = age_days
    output["candidate_set_size"] = frame.groupby("same_image_stratum_id")["arm_id"].transform("size")
    return output
