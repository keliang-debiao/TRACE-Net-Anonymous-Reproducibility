from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


class DisjointSet:
    def __init__(self, values):
        self.parent = {str(v): str(v) for v in values}

    def find(self, value: str) -> str:
        value = str(value)
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: str, right: str) -> None:
        a, b = self.find(left), self.find(right)
        if a != b:
            self.parent[max(a, b)] = min(a, b)


def leakage_components(frame: pd.DataFrame) -> pd.Series:
    ids = frame["arm_id"].astype(str).tolist()
    dsu = DisjointSet(ids)
    for columns in (("test_id",), ("normalized_headline", "normalized_context", "eyecatcher_id")):
        grouped = frame.groupby(list(columns), sort=False)["arm_id"]
        for _, values in grouped:
            values = values.astype(str).tolist()
            for value in values[1:]:
                dsu.union(values[0], value)
    roots = [dsu.find(value) for value in ids]
    mapping = {root: index for index, root in enumerate(sorted(set(roots)))}
    return pd.Series([mapping[root] for root in roots], index=frame.index, name="leakage_component")


def assign_outer_folds(frame: pd.DataFrame, folds: int = 5) -> pd.Series:
    required = {"leakage_component", "calendar_quarter", "impressions", "arm_id"}
    if missing := required.difference(frame.columns):
        raise ValueError(f"missing split columns: {sorted(missing)}")
    work = frame.copy()
    work["exposure_quartile"] = pd.qcut(work["impressions"], 4, labels=False, duplicates="drop")
    quarter = pd.get_dummies(work["calendar_quarter"], prefix="quarter", dtype=float)
    exposure = pd.get_dummies(work["exposure_quartile"], prefix="exposure", dtype=float)
    design = pd.concat([pd.Series(1.0, index=work.index, name="arms"), quarter, exposure], axis=1)
    design["leakage_component"] = work["leakage_component"].to_numpy()
    components = design.groupby("leakage_component").sum()
    components["impressions"] = work.groupby("leakage_component").impressions.sum()
    components = components.sort_values(["arms", "impressions"], ascending=False)
    balance_columns = [column for column in components if column != "impressions"]
    target = components[balance_columns].sum().to_numpy(dtype=float) / folds
    target = np.maximum(target, 1.0)
    fold_load = np.zeros((folds, len(balance_columns)), dtype=np.float64)
    assignment = {}
    for component, row in components.iterrows():
        vector = row[balance_columns].to_numpy(dtype=float)
        scores = [np.square((fold_load[index] + vector) / target).sum() for index in range(folds)]
        chosen = int(np.argmin(scores))
        assignment[component] = chosen + 1
        fold_load[chosen] += vector
    return work["leakage_component"].map(assignment).astype(int).rename("outer_fold")


def assert_partition_disjointness(frame: pd.DataFrame, partition_column: str) -> None:
    counts = frame.groupby("leakage_component")[partition_column].nunique()
    if int(counts.max()) != 1:
        raise AssertionError("a leakage component crosses partitions")
