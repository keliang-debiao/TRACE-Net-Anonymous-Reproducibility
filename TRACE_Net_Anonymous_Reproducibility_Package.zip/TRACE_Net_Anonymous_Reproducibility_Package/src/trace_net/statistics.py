from __future__ import annotations

import numpy as np


def paired_cluster_resample(left, right, clusters, draws: int = 10000, seed: int = 2026):
    left = np.asarray(left, dtype=np.float64)
    right = np.asarray(right, dtype=np.float64)
    clusters = np.asarray(clusters)
    unique = np.unique(clusters)
    rng = np.random.default_rng(seed)
    observed = float(np.mean(left - right))
    replicates = np.empty(draws, dtype=np.float64)
    for index in range(draws):
        selected = rng.choice(unique, size=len(unique), replace=True)
        positions = np.concatenate([np.where(clusters == cluster)[0] for cluster in selected])
        replicates[index] = np.mean(left[positions] - right[positions])
    interval = np.quantile(replicates, [0.025, 0.975])
    p_value = 2.0 * min(np.mean(replicates <= 0), np.mean(replicates >= 0))
    return {"difference": observed, "ci_low": float(interval[0]), "ci_high": float(interval[1]), "p_value": float(min(p_value, 1.0))}


def holm_adjust(p_values):
    p = np.asarray(p_values, dtype=np.float64)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    count = len(p)
    for rank, index in enumerate(order):
        running = max(running, (count - rank) * p[index])
        adjusted[index] = min(running, 1.0)
    return adjusted
