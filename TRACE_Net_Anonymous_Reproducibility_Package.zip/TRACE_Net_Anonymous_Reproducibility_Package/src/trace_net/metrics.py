from __future__ import annotations

import math
from collections.abc import Iterable

import numpy as np


T_CRITICAL_DF4 = 2.7764451051977987


def fold_summary(values: Iterable[float]) -> dict[str, float]:
    values = np.asarray(list(values), dtype=np.float64)
    if values.shape != (5,):
        raise ValueError("the locked fold summary requires exactly five outer-fold values")
    mean = float(values.mean())
    sd = float(values.std(ddof=1))
    margin = T_CRITICAL_DF4 * sd / math.sqrt(5.0)
    return {"mean": mean, "sd": sd, "ci_low": mean - margin, "ci_high": mean + margin}


def observed_winner_set(clicks: Iterable[int], impressions: Iterable[int], arm_ids: Iterable[str]) -> set[str]:
    clicks = np.asarray(list(clicks), dtype=np.float64)
    impressions = np.asarray(list(impressions), dtype=np.float64)
    ids = np.asarray([str(v) for v in arm_ids])
    if np.any(impressions <= 0):
        raise ValueError("impressions must be positive")
    ctr = clicks / impressions
    return set(ids[np.isclose(ctr, ctr.max(), rtol=0.0, atol=0.0)].tolist())


def predicted_winner(probabilities: Iterable[float], arm_ids: Iterable[str], tolerance: float = 1e-12) -> str:
    probabilities = np.asarray(list(probabilities), dtype=np.float64)
    ids = np.asarray([str(v) for v in arm_ids])
    top = probabilities.max()
    tied = ids[np.abs(probabilities - top) <= tolerance]
    return str(sorted(tied.tolist())[0])


def winner_is_correct(clicks, impressions, probabilities, arm_ids, tolerance: float = 1e-12) -> bool:
    return predicted_winner(probabilities, arm_ids, tolerance) in observed_winner_set(clicks, impressions, arm_ids)


def balanced_selective_risk(labels, probabilities, tau: float, gamma: float) -> dict[str, float]:
    y = np.asarray(labels, dtype=np.int64)
    p = np.asarray(probabilities, dtype=np.float64)
    keep = np.abs(p - tau) >= gamma
    if not keep.any():
        raise ValueError("the retained set is empty")
    prediction = p[keep] >= tau
    truth = y[keep] == 1
    positives = int(truth.sum())
    negatives = int((~truth).sum())
    if positives == 0 or negatives == 0:
        raise ValueError("both outcome classes must occur in the retained set")
    false_positive_rate = float((prediction & ~truth).sum() / negatives)
    false_negative_rate = float((~prediction & truth).sum() / positives)
    return {
        "risk": 0.5 * (false_positive_rate + false_negative_rate),
        "retained_fraction": float(keep.mean()),
        "false_positive_rate": false_positive_rate,
        "false_negative_rate": false_negative_rate,
    }


def select_operating_point(labels, probabilities, tau_values, gamma_values, minimum_retained: float = 0.60) -> dict[str, float]:
    candidates = []
    for tau in tau_values:
        for gamma in gamma_values:
            try:
                result = balanced_selective_risk(labels, probabilities, float(tau), float(gamma))
            except ValueError:
                continue
            if result["retained_fraction"] >= minimum_retained:
                candidates.append((result["risk"], -result["retained_fraction"], float(gamma), float(tau), result))
    if not candidates:
        raise ValueError("no operating point satisfies the retained-fraction constraint")
    risk, _, gamma, tau, result = min(candidates)
    return {"tau": tau, "gamma": gamma, **result}
