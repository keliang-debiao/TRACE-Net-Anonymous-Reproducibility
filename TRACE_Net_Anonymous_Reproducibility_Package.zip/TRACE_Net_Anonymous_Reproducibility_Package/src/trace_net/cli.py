from __future__ import annotations

import argparse
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="TRACE-Net reproducibility command")
    parser.add_argument("command", choices=["verify", "reference"])
    arguments = parser.parse_args()
    script = "verify_package.py" if arguments.command == "verify" else "build_reference_artifacts.py"
    return subprocess.call([sys.executable, f"scripts/{script}", "--check"] if arguments.command == "reference" else [sys.executable, f"scripts/{script}"])


if __name__ == "__main__":
    raise SystemExit(main())
