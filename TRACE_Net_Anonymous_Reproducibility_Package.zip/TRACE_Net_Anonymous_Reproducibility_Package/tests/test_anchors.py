import numpy as np
import pandas as pd

from trace_net.anchors import summarize_anchor_tuple


def test_anchor_requires_test_exposure_and_sign_support():
    rows = []
    for period, effect in [(0, 0.20), (1, 0.30)]:
        for test in range(2):
            for index in range(8):
                rows.append({
                    "period": period, "test_id": f"{period}-{test}", "impressions": 100,
                    "log_effect": effect, "propensity_target": 0.5,
                    "outcome_source": 0.20, "outcome_target": 0.30,
                })
    result = summarize_anchor_tuple(pd.DataFrame(rows))
    assert result["eligible"]
    assert np.isclose(result["ratio"], 1.5)


def test_anchor_rejects_low_exposure():
    frame = pd.DataFrame({
        "period": [0, 0, 1, 1], "test_id": ["a", "b", "c", "d"], "impressions": [100, 100, 100, 100],
        "log_effect": [0.2, 0.2, 0.3, 0.3], "propensity_target": [0.5] * 4,
        "outcome_source": [0.2] * 4, "outcome_target": [0.3] * 4,
    })
    result = summarize_anchor_tuple(frame)
    assert result == {"eligible": False, "reason": "exposure"}
