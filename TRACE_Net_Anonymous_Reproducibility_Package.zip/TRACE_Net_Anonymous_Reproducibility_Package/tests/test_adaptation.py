import numpy as np

from trace_net.adaptation import audited_binary_calibration, cross_fitted_density_ratio


def test_density_ratio_is_cross_fitted_and_clipped():
    source = np.column_stack([np.linspace(-1, 0, 20), np.zeros(20)])
    target = np.column_stack([np.linspace(0, 1, 20), np.ones(20)])
    weights = cross_fitted_density_ratio(source, target, np.arange(20), np.arange(20))
    assert weights.shape == (20,)
    assert np.all(weights >= 0.1)
    assert np.all(weights <= 10.0)


def test_audit_calibration_returns_frozen_quantities():
    labels = np.array([0, 0, 0, 1, 1, 1])
    probability = np.array([0.01, 0.02, 0.03, 0.07, 0.08, 0.09])
    result = audited_binary_calibration(labels, probability)
    assert 0.0 <= result["binary_quantile"] <= 1.0
    assert result["retained_fraction"] >= 0.60
