import numpy as np

from trace_net.metrics import balanced_selective_risk, fold_summary, observed_winner_set, predicted_winner, winner_is_correct


def test_observed_tie_and_predicted_tie_rules():
    arm_ids = ["b", "a", "c"]
    clicks = [10, 20, 5]
    impressions = [100, 200, 100]
    probabilities = [0.6, 0.6 + 5e-13, 0.4]
    assert observed_winner_set(clicks, impressions, arm_ids) == {"a", "b"}
    assert predicted_winner(probabilities, arm_ids) == "a"
    assert winner_is_correct(clicks, impressions, probabilities, arm_ids)


def test_balanced_selective_risk():
    result = balanced_selective_risk([0, 0, 1, 1], [0.1, 0.9, 0.8, 0.2], tau=0.5, gamma=0.2)
    assert np.isclose(result["risk"], 0.5)
    assert np.isclose(result["retained_fraction"], 1.0)


def test_five_fold_summary():
    result = fold_summary([0.817, 0.842, 0.789, 0.861, 0.828])
    assert np.isclose(result["mean"], 0.8274)
    assert np.isclose(result["sd"], 0.027043, atol=1e-6)
