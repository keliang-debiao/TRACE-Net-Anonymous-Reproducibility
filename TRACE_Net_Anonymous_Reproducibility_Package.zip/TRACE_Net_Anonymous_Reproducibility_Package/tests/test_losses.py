import numpy as np

from trace_net.losses import _numpy_beta_binomial_terms, bb_enll_nats_per_impression, beta_binomial_count_nll


def test_count_and_sequence_losses_have_declared_relationship():
    clicks = np.array([10, 20])
    impressions = np.array([100, 200])
    probability = np.array([0.1, 0.1])
    concentration = np.array([50.0, 50.0])
    sequence, combination = _numpy_beta_binomial_terms(clicks, impressions, probability, concentration)
    count = beta_binomial_count_nll(clicks, impressions, probability, concentration, reduction="sum")
    assert np.isclose(count, -(sequence + combination).sum())
    assert np.isclose(bb_enll_nats_per_impression(clicks, impressions, probability, concentration), -sequence.sum() / 300.0)


def test_exposure_denominator_is_global():
    value = bb_enll_nats_per_impression([2], [10], [0.2], [25.0])
    doubled = bb_enll_nats_per_impression([2, 2], [10, 10], [0.2, 0.2], [25.0, 25.0])
    assert np.isclose(value, doubled)
