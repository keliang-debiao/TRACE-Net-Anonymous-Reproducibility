import json
from pathlib import Path

import pandas as pd

from trace_net.splitting import assert_partition_disjointness, leakage_components


def test_locked_count_partitions_close():
    root = Path(__file__).resolve().parents[1]
    counts = json.loads((root / "manifests/expected_counts.json").read_text())
    for field in ("arms", "clicks", "impressions"):
        assert sum(row[field] for row in counts["outer_folds"]) == counts["upworthy_primary"][field]
    late = counts["late_holdout"]
    assert late["anchor"]["supported"] + late["anchor"]["unsupported"] == late["holdout"]["strata"]
    mind = counts["mind_small"]
    assert mind["clicked"] + mind["not_clicked"] == mind["candidate_exposures"]


def test_connected_recurrence_cannot_cross_partitions():
    frame = pd.DataFrame({
        "arm_id": ["a", "b", "c"], "test_id": ["x", "x", "y"],
        "normalized_headline": ["h1", "h2", "h1"], "normalized_context": ["c", "c", "c"],
        "eyecatcher_id": ["i", "i", "i"],
    })
    frame["leakage_component"] = leakage_components(frame)
    assert frame.leakage_component.nunique() == 1
    frame["partition"] = "fit"
    assert_partition_disjointness(frame, "partition")
