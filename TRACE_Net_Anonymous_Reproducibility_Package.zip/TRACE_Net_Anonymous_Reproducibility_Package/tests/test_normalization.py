from trace_net.normalization import normalize_text, temporal_key


def test_normalization_is_deterministic_and_exact():
    assert normalize_text("  Headline—Text!  ") == "headline—text"
    assert normalize_text(None) == "[missing]"
    assert temporal_key("A", "B", 7) == ("a", "b", "7")
