import numpy as np

from trace_net.conformal import binary_lac_quantile, binary_prediction_sets, weighted_quantile


def test_weighted_quantile_uses_smallest_crossing_score():
    assert weighted_quantile([0.1, 0.2, 0.3], [1, 1, 8], 0.5) == 0.3


def test_binary_prediction_set_contract():
    quantile = binary_lac_quantile([0, 1], [0.1, 0.9], [1, 1], coverage=0.9)
    sets = binary_prediction_sets([0.1, 0.9, 0.5], quantile)
    assert sets[0] == (0,)
    assert sets[1] == (1,)
    assert sets[2] == ()
