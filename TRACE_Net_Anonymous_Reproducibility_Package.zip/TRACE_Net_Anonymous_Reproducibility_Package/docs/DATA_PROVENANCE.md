# Public data provenance and integrity

## Upworthy

The development data are retrieved from the Kaggle dataset `akshaysyal/heading-performance-analysis`, which mirrors the public Upworthy Research Archive. The preparation script retains source files unchanged under `data/raw/upworthy`, writes their SHA-256 values to the run manifest, and creates a separate processed Parquet file.

The half-open initiation-date interval `[2013-06-25, 2014-01-11)` is removed before cohort formation. The primary cohort then retains within-test, same-eyecatcher strata containing at least two distinct normalized headlines. Processed counts must equal the locked manifest before training starts.

## MIND-small

MIND-small is retrieved from the official public release endpoint. The parser reads `news.tsv` and `behaviors.tsv`, expands each impression slate into candidate exposures, and verifies that clicked and nonclicked labels sum to the total candidate count. MIND labels are observational and are used only for cross-publisher click prediction, calibration, and selective classification evaluation; they do not validate causal lift.

## Redistribution

No source record is included in this repository. Downloading and use remain subject to the terms of the respective data providers.
