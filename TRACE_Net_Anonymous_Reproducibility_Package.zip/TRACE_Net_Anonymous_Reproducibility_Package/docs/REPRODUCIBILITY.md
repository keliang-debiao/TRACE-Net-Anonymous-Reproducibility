# Reproducibility protocol

## Execution order

1. Fetch the two public sources.
2. Normalize text deterministically and exclude the prespecified risk window.
3. Retain Upworthy same-test, same-eyecatcher strata with at least two distinct headlines.
4. Audit global counts and immutable identifiers.
5. Construct the leakage graph before any outcome-dependent fitting.
6. Assign graph components to five outer folds while balancing calendar quarter, exposure quartile, and arm count.
7. For each outer fold, create a group-disjoint 15% calibration subset from the remaining data and three group-aware inner folds from the model-fitting subset.
8. Rebuild eligible temporal anchors and all nuisance predictions inside that model-fitting subset.
9. Fit five seeds for the inner-selected configuration, average probabilities, and calculate one metric vector on the outer test fold.
10. Retain the five source-fold models separately for MIND validation.

## Leakage invariants

- Normalization precedes recurrence detection.
- Connected records cannot cross model-fitting, calibration, and test partitions.
- Anchor discovery never sees calibration or outer-test records.
- Nuisance predictions for an anchor are produced by a partition that did not fit that anchor.
- Feature standardization, missingness handling, density-ratio fitting, temperature, conformal quantiles, and decision thresholds are fit only on the partition allowed by the named protocol.
- External-0 opens MIND labels only after every source-side quantity is frozen.
- External audit sampling is slate-disjoint; every candidate from an audited slate is removed from that repetition's evaluation set.

## Run records

Each real run writes:

- resolved configuration and source checksums;
- software and accelerator inventory;
- fold, seed, and partition fingerprints;
- epoch-level optimization and validation metrics;
- stopping epoch and checkpoint checksum;
- prediction-table checksum;
- final metric vector and uncertainty calculation.

The run directory name is `protocol__fold-N__seed-N__UTC`. No personal or machine-specific name is recorded.
