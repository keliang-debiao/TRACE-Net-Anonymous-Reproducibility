# Computational definitions

## Exact text key

Unicode NFKC normalization is followed by lowercasing, whitespace collapse, and removal of boundary punctuation. Internal punctuation is preserved. A temporal key is the ordered tuple `(normalized_headline, normalized_context, eyecatcher_id)`. Approximate semantic matches are not admitted.

## Doubly robust temporal target

For each legal model-fitting partition, an anchor record carries a period indicator `D`, a signed log-effect outcome `Y`, fold-legal covariates `X`, and impression weight `w`. Five group-disjoint nuisance partitions are used. The propensity `e(X)=P(D=1|X)` is fitted by L2 logistic regression. Separate source and target outcome regressions `m_0(X)` and `m_1(X)` are fitted by LightGBM with impression weights.

For period `d` in `{0,1}`, the cross-fitted augmented inverse-probability estimate within an anchor tuple is

`Delta_d = weighted_mean(m_d(X) + I(D=d) * (Y-m_d(X)) / P(D=d|X))`.

Propensities are clipped to `[0.01,0.99]`. The standard error is calculated from the weighted empirical influence values with an effective-sample-size correction. Source and target estimates must have the same nonzero sign, and both 90% Wald intervals must exclude zero. The positive target is `rho=abs(Delta_1/Delta_0)` and the temporal objective uses `log(rho)`. Ratios are clipped at the first and ninety-ninth percentiles learned from eligible training anchors. When support fails, the untransported lift and variance pass to calibration.

## Beta-binomial objectives

For clicks `y`, impressions `n`, mean probability `p`, and concentration `kappa`, define `alpha=p*kappa` and `beta=(1-p)*kappa`. The optimization loss per arm is the negative beta-binomial count log likelihood

`-[log C(n,y) + log B(y+alpha,n-y+beta) - log B(alpha,beta)]`.

The reported BB-ENLL removes `log C(n,y)` and divides the summed negative sequence log probability by the summed impressions. Natural logarithms are used, so the reporting unit is nats per impression. Count NLL and BB-ENLL are deliberately separate functions in the source code.

## Conformal procedures

Upworthy lift intervals use weighted absolute residual scores from the disjoint calibration subset. The weighted finite-sample quantile uses the smallest score whose cumulative normalized mass reaches the requested level. MIND binary prediction sets use the label-conditional nonconformity score `1-p_y`; label `y` is included when its score does not exceed the frozen weighted calibration quantile. External-U changes calibration weights only. External-A changes only the permitted calibration quantities; representation and model weights remain fixed.

## Winner and selective-decision rules

The observed winner set contains all arms at the maximum empirical CTR in a same-image stratum. The predicted winner is the largest predicted probability, with probability ties within `1e-12` resolved by ascending immutable arm identifier. Membership in the observed set defines correctness.

For MIND, retain candidate `i` when `abs(p_i-tau)>=gamma`. Among retained candidates, risk is half the retained false-positive rate plus half the retained false-negative rate. `tau` and `gamma` are selected on source calibration data to minimize this risk subject to retained fraction at least 0.60. Empty class denominators are invalid and stop evaluation.

## Aggregation and inference

Five seed-level probability vectors are averaged before metrics are calculated. This yields one vector per outer fold. Means, sample standard deviations, and 95% Student-t intervals use the five fold vectors and four degrees of freedom. Paired claims use 10,000 same-image-stratum cluster resamples with Holm adjustment; seed-fold pairs are never counted as independent observations.
